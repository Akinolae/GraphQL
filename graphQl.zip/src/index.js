exports.handler = async () => {
    return {
        body: "Hello Lambda"
    }
}